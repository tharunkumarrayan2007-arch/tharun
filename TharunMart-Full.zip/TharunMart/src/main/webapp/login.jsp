<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Login - Tharun Mart</title>
<style>
:root{--line:rgba(0,200,255,.18);--cyan:#2dd4bf;--text:#e8f4ff;--muted:#8ba3c7}
*{box-sizing:border-box;margin:0;padding:0;font-family:Segoe UI,sans-serif}
body{min-height:100vh;display:flex;align-items:center;justify-content:center;background:radial-gradient(ellipse at 30% 20%,#0d1b3d,#050814);color:var(--text)}
.card{width:400px;padding:32px;background:rgba(10,30,60,.6);border:1px solid var(--line);border-radius:18px;box-shadow:0 0 40px rgba(0,180,216,.12)}
.logo{text-align:center;margin-bottom:16px}
h2{text-align:center;margin-bottom:6px}
.sub{text-align:center;color:var(--muted);font-size:.9rem;margin-bottom:18px}
input{width:100%;padding:12px;margin:8px 0;border-radius:10px;border:1px solid var(--line);background:#0a1628;color:#fff}
button{width:100%;padding:13px;margin-top:12px;border:none;border-radius:10px;background:linear-gradient(135deg,#14b8a6,#10b981);color:#fff;font-weight:700;cursor:pointer}
a{color:var(--cyan)} .err{color:#fca5a5;text-align:center;margin-top:10px;display:none}
.hint{margin-top:16px;font-size:.78rem;color:var(--muted);line-height:1.5}
.hint code{color:var(--cyan)}
</style></head><body>
<div class="card">
  <div class="logo">
    <svg width="56" height="56" viewBox="0 0 64 64"><rect x="4" y="4" width="56" height="56" rx="14" stroke="#2dd4bf" stroke-width="2.5" fill="rgba(0,229,255,.08)"/><path d="M18 40V24h8c5 0 8 2.5 8 7s-3 9-8 9h-8zm8-5c2.2 0 3.5-1.2 3.5-3.5S28.2 28 26 28h-3v7h3z" fill="#2dd4bf"/><path d="M38 40V24h12v5h-7v2h6v4h-6v5H38z" fill="#10b981"/></svg>
  </div>
  <h2>Sign in to Tharun Mart</h2>
  <p class="sub">Tharun Mart · Your online marketplace</p>
  <div class="err" id="err"></div>
  <input id="email" type="email" placeholder="Email">
  <input id="password" type="password" placeholder="Password">
  <button onclick="go()">Login</button>
  <p style="text-align:center;margin-top:14px"><a href="register.jsp">Create account</a> · <a href="index.jsp">Home</a></p>
  <div class="hint"><b>Demo</b> (password <code>password123</code>)<br>
  Admin <code>admin@tharunmart.com</code> · Seller <code>ravi@tharunmart.com</code> · Buyer <code>amit@tharunmart.com</code></div>
</div>
<script>
async function go(){
  try{
    const r=await fetch('api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({email:document.getElementById('email').value,password:document.getElementById('password').value})});
    const j=await r.json();
    if(j.success){
      if(j.data.role==='ADMIN') location='admin.jsp';
      else if(j.data.role==='SELLER') location='seller.jsp';
      else location='index.jsp';
    } else { document.getElementById('err').style.display='block'; document.getElementById('err').innerText=j.error?j.error.message:'Failed'; }
  }catch(e){ document.getElementById('err').style.display='block'; document.getElementById('err').innerText='Network error'; }
}
</script></body></html>
