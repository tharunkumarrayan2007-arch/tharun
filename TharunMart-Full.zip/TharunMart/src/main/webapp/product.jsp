<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Product - Tharun Mart</title>
<style>
:root{--line:rgba(0,200,255,.18);--cyan:#2dd4bf;--text:#e8f4ff;--muted:#8ba3c7}
*{box-sizing:border-box;margin:0;padding:0;font-family:Segoe UI,sans-serif}
body{min-height:100vh;background:radial-gradient(ellipse at 20% 0%,#0d1b3d,#050814);color:var(--text)}
.nav{display:flex;justify-content:space-between;padding:12px 24px;background:rgba(5,12,28,.92);border-bottom:1px solid var(--line)}
.nav a{color:var(--muted);text-decoration:none;margin-left:14px}
.brand{color:var(--cyan);font-weight:700;text-decoration:none}
.wrap{max-width:1000px;margin:24px auto;padding:0 20px}
.main{display:flex;gap:24px;flex-wrap:wrap;background:rgba(10,30,60,.55);border:1px solid var(--line);border-radius:16px;padding:22px}
.main img{max-width:360px;width:100%;border-radius:12px;background:#0a1628}
.price{font-size:1.7rem;color:var(--cyan);font-weight:700;margin:10px 0}
.btn{padding:11px 20px;border:none;border-radius:10px;background:linear-gradient(135deg,#14b8a6,#10b981);color:#fff;font-weight:600;cursor:pointer}
.rev{margin-top:20px;background:rgba(10,30,60,.55);border:1px solid var(--line);border-radius:16px;padding:20px}
.star-pick{display:flex;gap:6px;margin:10px 0}
.star-pick button{width:38px;height:38px;border-radius:8px;border:1px solid var(--line);background:rgba(0,0,0,.25);color:#fbbf24;cursor:pointer}
.star-pick button.on{background:rgba(251,191,36,.2);border-color:#fbbf24}
textarea{width:100%;padding:10px;margin:8px 0;border-radius:10px;border:1px solid var(--line);background:#0a1628;color:#fff}
.stars{color:#fbbf24}
.hide{display:none!important}
</style></head><body>
<nav class="nav"><a class="brand" href="index.jsp">Tharun Mart</a><div id="navR"><a href="index.jsp">Shop</a></div></nav>
<div class="wrap">
  <div class="main" id="p">Loading...</div>
  <div class="rev">
    <h3>Customer reviews</h3>
    <p id="avg" style="color:var(--muted);margin:8px 0"></p>
    <div id="r">...</div>
    <div id="reviewForm" class="hide">
      <p style="margin-top:12px">Your rating (1–5)</p>
      <div class="star-pick" id="starPick">
        <button type="button" data-v="1" onclick="setStar(1)">★</button>
        <button type="button" data-v="2" onclick="setStar(2)">★</button>
        <button type="button" data-v="3" onclick="setStar(3)">★</button>
        <button type="button" data-v="4" onclick="setStar(4)">★</button>
        <button type="button" data-v="5" onclick="setStar(5)">★</button>
      </div>
      <textarea id="comment" rows="2" placeholder="Write a review"></textarea>
      <button class="btn" onclick="review()">Submit</button>
      <p id="msg"></p>
    </div>
    <p id="reviewNote" style="color:var(--muted);font-size:.9rem"></p>
  </div>
</div>
<script>
var id=new URLSearchParams(location.search).get('id'), currentUser=null, selectedStar=5;
async function init(){
  try{ const r=await fetch('api/auth/me'); const j=await r.json(); if(j.success) currentUser=j.data; }catch(e){}
  var nav=document.getElementById('navR');
  if(currentUser&&currentUser.role==='BUYER') nav.innerHTML='<a href="index.jsp">Shop</a><a href="cart.jsp">Cart</a>';
  else if(currentUser&&currentUser.role==='SELLER') nav.innerHTML='<a href="seller.jsp">Dashboard</a><a href="index.jsp">Store</a>';
  else nav.innerHTML='<a href="index.jsp">Shop</a><a href="login.jsp">Login</a>';
  if(currentUser&&currentUser.role==='BUYER'){ document.getElementById('reviewForm').classList.remove('hide'); }
  else document.getElementById('reviewNote').innerText=currentUser?'Only buyers can submit reviews.':'Login as Buyer to review.';
  setStar(5); if(id){ load(); loadR(); } else document.getElementById('p').innerHTML='No id';
}
function setStar(n){ selectedStar=n; document.querySelectorAll('#starPick button').forEach(function(b){ b.classList.toggle('on', Number(b.getAttribute('data-v'))<=n); }); }
async function load(){
  const r=await fetch('api/products/'+id); const j=await r.json();
  if(!j.success){ document.getElementById('p').innerHTML='Not found'; return; }
  var p=j.data, isBuyer=currentUser&&currentUser.role==='BUYER';
  document.getElementById('p').innerHTML='<div><img src="'+(p.imageUrl||'https://via.placeholder.com/400')+'"></div>'+
    '<div><h1>'+p.name+'</h1><div class="price">₹'+p.price+'</div>'+
    '<p style="color:#8ba3c7">'+(p.category||'')+' · '+(p.sellerName||'')+' · Stock '+p.stockQty+'</p>'+
    '<p style="margin:14px 0">'+(p.description||'')+'</p>'+(isBuyer?'<button class="btn" onclick="add()">Add to Cart</button>':'')+'</div>';
}
async function add(){
  const r=await fetch('api/cart',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({productId:Number(id),quantity:1})});
  const j=await r.json(); if(j.success) alert('Added!'); else alert(j.error?j.error.message:'Login as Buyer');
}
async function loadR(){
  const r=await fetch('api/reviews/'+id); const j=await r.json();
  if(!j.success||!j.data.length){ document.getElementById('r').innerHTML='<p style="color:#8ba3c7">No reviews</p>'; return; }
  var sum=0; j.data.forEach(function(x){ sum+=Number(x.rating)||0; });
  var avg=(sum/j.data.length).toFixed(1);
  document.getElementById('avg').innerHTML='Average: <span class="stars">'+'★'.repeat(Math.round(avg))+'</span> '+avg+'/5';
  document.getElementById('r').innerHTML=j.data.map(function(x){
    return '<div style="padding:8px 0;border-bottom:1px solid rgba(255,255,255,.08)"><b>'+(x.userName||'User')+'</b> <span class="stars">'+'★'.repeat(x.rating)+'</span> ('+x.rating+'/5)<p>'+(x.comment||'')+'</p></div>';
  }).join('');
}
async function review(){
  const r=await fetch('api/reviews',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({productId:Number(id),rating:selectedStar,comment:document.getElementById('comment').value})});
  const j=await r.json();
  if(j.success){ document.getElementById('msg').innerHTML='<span style="color:#34d399">Submitted</span>'; loadR(); }
  else document.getElementById('msg').innerHTML='<span style="color:#fca5a5">'+(j.error?j.error.message:'Failed')+'</span>';
}
init();
</script></body></html>
