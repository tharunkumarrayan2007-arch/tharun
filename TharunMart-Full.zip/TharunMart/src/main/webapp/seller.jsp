<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Seller - Tharun Mart</title>
<style>
:root{--line:rgba(0,200,255,.18);--cyan:#2dd4bf;--text:#e8f4ff;--muted:#8ba3c7}
*{box-sizing:border-box;margin:0;padding:0;font-family:Segoe UI,sans-serif}
body{min-height:100vh;background:radial-gradient(ellipse at 20% 0%,#0d1b3d,#050814);color:var(--text)}
.nav{display:flex;justify-content:space-between;padding:12px 24px;background:rgba(5,12,28,.92);border-bottom:1px solid var(--line);align-items:center}
.nav a,.nav button{color:var(--muted);text-decoration:none;margin-left:12px;background:none;border:none;cursor:pointer}
.brand{color:var(--cyan);font-weight:700}
.wrap{max-width:960px;margin:22px auto;padding:0 20px}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:18px}
.stat{background:rgba(10,30,60,.55);border:1px solid var(--line);border-radius:14px;padding:16px;text-align:center}
.stat b{display:block;font-size:1.5rem;color:var(--cyan)}
.card{background:rgba(10,30,60,.55);border:1px solid var(--line);border-radius:16px;padding:20px;margin-bottom:16px}
input,select,textarea{width:100%;padding:10px;margin:6px 0 12px;border-radius:10px;border:1px solid var(--line);background:#0a1628;color:#fff}
select option{background:#0a1628}
button.primary{background:linear-gradient(135deg,#059669,#0ea5e9);color:#fff;border:none;padding:10px 16px;border-radius:10px;cursor:pointer;font-weight:600;margin-right:8px}
button.edit{background:#10b981;color:#fff;border:none;padding:5px 10px;border-radius:6px;cursor:pointer}
button.del{background:#ef4444;color:#fff;border:none;padding:5px 10px;border-radius:6px;cursor:pointer}
table{width:100%;border-collapse:collapse;font-size:.9rem} th,td{padding:9px;border-bottom:1px solid rgba(255,255,255,.08);text-align:left}
.pill{background:rgba(0,229,255,.12);color:var(--cyan);padding:4px 10px;border-radius:12px;font-size:.8rem}
</style></head><body>
<nav class="nav"><div class="brand">Tharun Mart Seller</div><div><span id="who" class="pill"></span><a href="index.jsp">Store</a><button onclick="logout()">Logout</button></div></nav>
<div class="wrap">
  <div class="stats"><div class="stat"><b id="sCount">0</b>Products</div><div class="stat"><b id="sStock">0</b>Stock</div></div>
  <div class="card"><h3 id="formTitle">Add product</h3><div id="msg"></div>
    <input id="name" placeholder="Name"><textarea id="desc" rows="2" placeholder="Description"></textarea>
    <input id="price" type="number" step="0.01" placeholder="Price"><input id="stock" type="number" placeholder="Stock">
    <select id="cat"><option>Electronics</option><option>Fashion</option><option>Other</option></select>
    <input id="img" placeholder="Image URL"><button class="primary" onclick="save()">Save</button>
    <button onclick="resetForm()" style="background:#475569;color:#fff;border:none;padding:10px 16px;border-radius:10px;cursor:pointer">Cancel</button>
  </div>
  <div class="card"><h3>My catalog</h3><div id="list">Loading...</div></div>
</div>
<script>
var editId=null, productsCache={}, me=null;
async function init(){
  try{ const r=await fetch('api/auth/me'); const j=await r.json();
    if(!j.success||(j.data.role!=='SELLER'&&j.data.role!=='ADMIN')){ alert('Seller login required'); location='login.jsp'; return; }
    me=j.data; document.getElementById('who').innerText=me.name+' · Seller';
  }catch(e){ location='login.jsp'; return; }
  load();
}
async function logout(){ await fetch('api/auth/logout'); location='index.jsp'; }
async function save(){
  var d={name:document.getElementById('name').value,description:document.getElementById('desc').value,
    price:parseFloat(document.getElementById('price').value),stockQty:parseInt(document.getElementById('stock').value)||0,
    category:document.getElementById('cat').value,imageUrl:document.getElementById('img').value};
  try{
    var r; if(editId){ d.id=editId; r=await fetch('api/products',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)}); }
    else r=await fetch('api/products',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)});
    var j=await r.json();
    if(j.success){ document.getElementById('msg').innerHTML='<span style="color:#34d399">Saved!</span>'; resetForm(); load(); }
    else document.getElementById('msg').innerHTML='<span style="color:#fca5a5">'+(j.error?j.error.message:'Failed')+'</span>';
  }catch(e){ document.getElementById('msg').innerHTML='Error'; }
}
function edit(id){ var p=productsCache[id]; if(!p) return; editId=p.id; document.getElementById('formTitle').innerText='Edit';
  document.getElementById('name').value=p.name; document.getElementById('desc').value=p.description||'';
  document.getElementById('price').value=p.price; document.getElementById('stock').value=p.stockQty;
  document.getElementById('cat').value=p.category||'Other'; document.getElementById('img').value=p.imageUrl||''; window.scrollTo(0,0); }
async function del(id){ if(!confirm('Delete?'))return; await fetch('api/products/'+id,{method:'DELETE'}); load(); }
function resetForm(){ editId=null; document.getElementById('formTitle').innerText='Add product';
  ['name','desc','price','stock','img'].forEach(function(i){document.getElementById(i).value='';}); document.getElementById('msg').innerHTML=''; }
async function load(){
  const r=await fetch('api/products'); const j=await r.json();
  if(!j.success||!j.data){ document.getElementById('list').innerHTML='No data'; return; }
  var mine=j.data.filter(function(p){ return !me || p.sellerId===me.id || me.role==='ADMIN'; });
  if(!mine.length) mine=j.data;
  productsCache={}; var stock=0;
  mine.forEach(function(p){ productsCache[p.id]=p; stock+=Number(p.stockQty)||0; });
  document.getElementById('sCount').innerText=mine.length; document.getElementById('sStock').innerText=stock;
  if(!mine.length){ document.getElementById('list').innerHTML='<p style="color:#8ba3c7">No products yet</p>'; return; }
  var h='<table><tr><th>Name</th><th>Price</th><th>Stock</th><th>Category</th><th></th></tr>';
  mine.forEach(function(p){
    h+='<tr><td>'+p.name+'</td><td>₹'+p.price+'</td><td>'+p.stockQty+'</td><td>'+(p.category||'')+
      '</td><td><button class="edit" onclick="edit('+p.id+')">Edit</button> <button class="del" onclick="del('+p.id+')">Del</button></td></tr>';
  });
  document.getElementById('list').innerHTML=h+'</table>';
}
init();
</script></body></html>
