<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Register - Tharun Mart</title>
<style>
:root{--line:rgba(0,200,255,.18);--cyan:#2dd4bf;--text:#e8f4ff;--muted:#8ba3c7}
*{box-sizing:border-box;margin:0;padding:0;font-family:Segoe UI,sans-serif}
body{min-height:100vh;display:flex;align-items:center;justify-content:center;background:radial-gradient(ellipse at 30% 20%,#0d1b3d,#050814);color:var(--text)}
.card{width:400px;padding:32px;background:rgba(10,30,60,.6);border:1px solid var(--line);border-radius:18px}
h2{text-align:center;margin-bottom:6px}
.sub{text-align:center;color:var(--muted);font-size:.9rem;margin-bottom:14px}
input{width:100%;padding:12px;margin:8px 0;border-radius:10px;border:1px solid var(--line);background:#0a1628;color:#fff}
button{width:100%;padding:13px;margin-top:10px;border:none;border-radius:10px;background:linear-gradient(135deg,#059669,#0ea5e9);color:#fff;font-weight:700;cursor:pointer}
a{color:var(--cyan)} .err{color:#fca5a5;text-align:center;margin-top:8px;display:none}
.roles{display:flex;gap:10px;margin:10px 0}
.role{flex:1;padding:12px;text-align:center;border:1px solid var(--line);border-radius:12px;cursor:pointer}
.role.on{border-color:var(--cyan);background:rgba(0,229,255,.12);color:var(--cyan)}
</style></head><body>
<div class="card">
  <h2>Create account</h2>
  <p class="sub">Buyer shops · Seller sells</p>
  <div class="err" id="err"></div>
  <input id="name" placeholder="Full name">
  <input id="email" type="email" placeholder="Email">
  <input id="password" type="password" placeholder="Password (min 6)">
  <div class="roles">
    <div class="role on" id="rBuyer" onclick="setRole('BUYER')">Buyer</div>
    <div class="role" id="rSeller" onclick="setRole('SELLER')">Seller</div>
  </div>
  <button onclick="go()">Register</button>
  <p style="text-align:center;margin-top:14px"><a href="login.jsp">Login</a></p>
</div>
<script>
var role='BUYER';
function setRole(r){ role=r; document.getElementById('rBuyer').classList.toggle('on',r==='BUYER'); document.getElementById('rSeller').classList.toggle('on',r==='SELLER'); }
async function go(){
  try{
    const r=await fetch('api/auth/register',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({name:document.getElementById('name').value,email:document.getElementById('email').value,password:document.getElementById('password').value,role:role})});
    const j=await r.json();
    if(j.success) location = j.data.role==='SELLER'?'seller.jsp':'index.jsp';
    else { document.getElementById('err').style.display='block'; document.getElementById('err').innerText=j.error?j.error.message:'Failed'; }
  }catch(e){ document.getElementById('err').style.display='block'; document.getElementById('err').innerText='Error'; }
}
</script></body></html>
