<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Orders - Tharun Mart</title>
<style>
:root{--line:rgba(0,200,255,.18);--cyan:#2dd4bf;--text:#e8f4ff;--muted:#8ba3c7}
*{box-sizing:border-box;margin:0;padding:0;font-family:Segoe UI,sans-serif}
body{min-height:100vh;background:radial-gradient(ellipse at 20% 0%,#0d1b3d,#050814);color:var(--text)}
.nav{display:flex;justify-content:space-between;padding:12px 24px;background:rgba(5,12,28,.92);border-bottom:1px solid var(--line)}
.nav a{color:var(--muted);text-decoration:none;margin-left:14px}
.brand{color:var(--cyan);font-weight:700;text-decoration:none}
.wrap{max-width:700px;margin:28px auto;padding:0 20px}
.o{background:rgba(10,30,60,.55);border:1px solid var(--line);border-radius:14px;padding:16px;margin:12px 0}
.badge{display:inline-block;padding:3px 8px;border-radius:10px;font-size:.75rem;background:rgba(0,229,255,.15);color:var(--cyan)}
</style></head><body>
<nav class="nav"><a class="brand" href="index.jsp">Tharun Mart</a><div><a href="index.jsp">Shop</a><a href="cart.jsp">Cart</a></div></nav>
<div class="wrap"><h2 style="margin-bottom:14px">My Orders</h2><div id="o">Loading...</div></div>
<script>
async function load(){
  try{
    const r=await fetch('api/orders'); const j=await r.json();
    if(!j.success){ document.getElementById('o').innerHTML='<p>Please <a href="login.jsp" style="color:#2dd4bf">login</a></p>'; return; }
    if(!j.data.length){ document.getElementById('o').innerHTML='<p style="color:#8ba3c7">No orders yet</p>'; return; }
    document.getElementById('o').innerHTML=j.data.map(function(o){
      var d=o.createdAt?String(o.createdAt).substring(0,10):'';
      var pay=o.name||'';
      var sub=o.price!=null?'Subtotal ₹'+o.price:'';
      var svc=o.unitPrice!=null?' · Service ₹'+o.unitPrice:'';
      var del=o.productPrice!=null?' · Delivery ₹'+o.productPrice:'';
      return '<div class="o"><div style="display:flex;justify-content:space-between"><div><b>Order #'+o.id+'</b><br><span style="color:#8ba3c7">'+d+'</span></div>'+
        '<span class="badge">'+o.status+'</span></div>'+
        '<p style="margin-top:8px;color:#8ba3c7;font-size:.85rem">'+pay+' '+sub+svc+del+'</p>'+
        '<p style="margin-top:6px;color:#2dd4bf;font-weight:700;font-size:1.1rem">Total ₹'+o.totalAmount+'</p></div>';
    }).join('');
  }catch(e){ document.getElementById('o').innerHTML='Error'; }
}
load();
</script></body></html>
