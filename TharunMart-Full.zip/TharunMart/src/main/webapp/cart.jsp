<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Cart - Tharun Mart</title>
<style>
:root{--line:rgba(0,200,255,.18);--cyan:#2dd4bf;--text:#e8f4ff;--muted:#8ba3c7}
*{box-sizing:border-box;margin:0;padding:0;font-family:Segoe UI,sans-serif}
body{min-height:100vh;background:radial-gradient(ellipse at 20% 0%,#0d1b3d,#050814);color:var(--text)}
.nav{display:flex;justify-content:space-between;padding:12px 24px;background:rgba(5,12,28,.92);border-bottom:1px solid var(--line)}
.nav a{color:var(--muted);text-decoration:none;margin-left:14px}
.brand{color:var(--cyan);font-weight:700;text-decoration:none}
.wrap{max-width:800px;margin:28px auto;padding:0 20px}
.card{background:rgba(10,30,60,.55);border:1px solid var(--line);border-radius:16px;padding:22px}
table{width:100%;border-collapse:collapse;margin:14px 0} th,td{padding:11px 8px;border-bottom:1px solid rgba(255,255,255,.08);text-align:left}
.total{text-align:right;font-size:1.2rem;color:var(--cyan);font-weight:700;margin:14px 0}
.btn{padding:12px 22px;border:none;border-radius:10px;background:linear-gradient(135deg,#14b8a6,#10b981);color:#fff;font-weight:600;cursor:pointer}
.del{background:#ef4444;color:#fff;border:none;padding:5px 10px;border-radius:6px;cursor:pointer}
.empty{text-align:center;padding:36px;color:var(--muted)}
.note{color:var(--muted);font-size:.85rem;margin-top:8px}
</style></head><body>
<nav class="nav"><a class="brand" href="index.jsp">Tharun Mart</a><div><a href="index.jsp">Shop</a><a href="orders.jsp">Orders</a></div></nav>
<div class="wrap"><div class="card"><h2>Shopping Cart</h2><div id="c">Loading...</div></div></div>
<script>
async function load(){
  try{
    const r=await fetch('api/cart'); const j=await r.json();
    if(!j.success){ document.getElementById('c').innerHTML='<div class="empty">Please <a href="login.jsp" style="color:#2dd4bf">login as Buyer</a></div>'; return; }
    if(!j.data.items||!j.data.items.length){ document.getElementById('c').innerHTML='<div class="empty">Cart empty. <a href="index.jsp" style="color:#2dd4bf">Shop</a></div>'; return; }
    var h='<table><tr><th>Product</th><th>Price</th><th>Qty</th><th>Subtotal</th><th></th></tr>';
    j.data.items.forEach(function(i){
      var sub=(Number(i.productPrice)*Number(i.quantity)).toFixed(2);
      h+='<tr><td>'+i.productName+'</td><td>₹'+i.productPrice+'</td><td>'+i.quantity+'</td><td>₹'+sub+
        '</td><td><button class="del" onclick="rm('+i.id+')">Remove</button></td></tr>';
    });
    h+='</table><div class="total">Items total: ₹'+j.data.total+'</div>'+
      '<p class="note">Service charge + delivery calculated at checkout (COD / UPI rates differ)</p>'+
      '<button class="btn" onclick="location=\'checkout.jsp\'">Proceed to Checkout</button>';
    document.getElementById('c').innerHTML=h;
  }catch(e){ document.getElementById('c').innerHTML='Error'; }
}
async function rm(id){ await fetch('api/cart/'+id,{method:'DELETE'}); load(); }
load();
</script></body></html>
