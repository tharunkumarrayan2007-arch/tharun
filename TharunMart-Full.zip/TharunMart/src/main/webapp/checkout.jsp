<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Checkout - Tharun Mart</title>
<style>
:root{--bg:#050814;--line:rgba(0,200,255,.18);--cyan:#2dd4bf;--blue:#10b981;--text:#e8f4ff;--muted:#8ba3c7}
*{box-sizing:border-box;margin:0;padding:0;font-family:Segoe UI,sans-serif}
body{min-height:100vh;background:radial-gradient(ellipse at 20% 0%,#0d1b3d,#050814);color:var(--text)}
.nav{display:flex;justify-content:space-between;align-items:center;padding:12px 24px;background:rgba(5,12,28,.92);border-bottom:1px solid var(--line)}
.nav a{color:var(--muted);text-decoration:none;margin-left:14px}
.brand{display:flex;align-items:center;gap:8px;font-weight:700;color:var(--cyan);text-decoration:none}
.wrap{max-width:560px;margin:32px auto;padding:0 20px}
.card{background:rgba(10,30,60,.55);border:1px solid var(--line);border-radius:16px;padding:26px}
h2{margin-bottom:6px}
.sub{color:var(--muted);margin-bottom:14px;font-size:.9rem}
.opt{display:block;padding:14px 16px;margin:10px 0;border:1px solid var(--line);border-radius:12px;cursor:pointer;background:rgba(0,0,0,.2)}
.opt.selected{border-color:var(--cyan);background:rgba(0,229,255,.1);box-shadow:0 0 12px rgba(0,229,255,.12)}
.opt input{margin-right:10px}
#upiBox{display:none;margin-top:14px}
input[type=text],input[type=password]{width:100%;padding:12px;margin:8px 0;border-radius:10px;border:1px solid var(--line);background:#0a1628;color:#fff}
.btn{width:100%;padding:14px;margin-top:16px;border:none;border-radius:12px;background:linear-gradient(135deg,#14b8a6,#10b981);color:#fff;font-weight:700;cursor:pointer}
.breakdown{background:rgba(0,0,0,.25);border-radius:12px;padding:14px;margin:12px 0;font-size:.92rem}
.breakdown div{display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid rgba(255,255,255,.06)}
.breakdown .grand{font-weight:700;color:var(--cyan);font-size:1.1rem;border:none;padding-top:10px}
.msg{margin-top:12px;padding:10px;border-radius:8px;display:none}
.ok{background:rgba(52,211,153,.15);color:#34d399}
.err{background:rgba(239,68,68,.15);color:#fca5a5}
#bill{display:none;margin-top:18px;padding:16px;border-radius:12px;background:rgba(0,0,0,.3);border:1px dashed var(--line)}
#bill table{width:100%;border-collapse:collapse;font-size:.88rem;margin-top:10px}
#bill th,#bill td{padding:7px 4px;border-bottom:1px solid rgba(255,255,255,.08);text-align:left}
</style></head><body>
<nav class="nav">
  <a class="brand" href="index.jsp">
    <svg width="28" height="28" viewBox="0 0 64 64"><rect x="4" y="4" width="56" height="56" rx="12" stroke="#2dd4bf" stroke-width="2.5" fill="rgba(0,229,255,.08)"/><text x="32" y="40" text-anchor="middle" fill="#2dd4bf" font-size="18" font-weight="700">PM</text></svg>
    Tharun Mart
  </a>
  <div><a href="cart.jsp">Cart</a><a href="index.jsp">Shop</a></div>
</nav>
<div class="wrap"><div class="card">
  <h2>Checkout</h2>
  <p class="sub">Service charge + delivery applied like real e-commerce</p>
  <div class="breakdown" id="bd">Loading charges...</div>
  <label class="opt selected" id="optCod" onclick="selectPay('COD')">
    <input type="radio" name="pay" value="COD" checked> Cash on Delivery (COD) — higher delivery
  </label>
  <label class="opt" id="optUpi" onclick="selectPay('ONLINE')">
    <input type="radio" name="pay" value="ONLINE"> Online UPI — lower delivery
  </label>
  <div id="upiBox">
    <label>UPI ID</label>
    <input type="text" id="upiId" placeholder="yourname@upi">
    <label>UPI PIN (demo)</label>
    <input type="password" id="upiPin" placeholder="Min 4 digits">
  </div>
  <button class="btn" id="placeBtn" onclick="placeOrder()">Place Order</button>
  <div class="msg" id="msg"></div>
  <div id="bill"></div>
</div></div>
<script>
var payMethod='COD';
function selectPay(m){
  payMethod=m;
  document.getElementById('optCod').classList.toggle('selected', m==='COD');
  document.getElementById('optUpi').classList.toggle('selected', m==='ONLINE');
  document.getElementById('upiBox').style.display = m==='ONLINE' ? 'block' : 'none';
  loadQuote();
}
async function loadQuote(){
  try{
    const r=await fetch('api/orders',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({paymentMethod:payMethod,quote:true})});
    const j=await r.json();
    if(!j.success){ document.getElementById('bd').innerHTML=j.error?j.error.message:'Cart empty'; document.getElementById('placeBtn').disabled=true; return; }
    var d=j.data;
    document.getElementById('placeBtn').disabled=false;
    document.getElementById('bd').innerHTML=
      '<div><span>Items subtotal</span><span>₹'+d.subtotal+'</span></div>'+
      '<div><span>Service charge ('+d.servicePercent+')</span><span>₹'+d.serviceCharge+'</span></div>'+
      '<div><span>Delivery <small style="color:#8ba3c7">('+d.deliveryNote+')</small></span><span>₹'+d.deliveryCharge+'</span></div>'+
      '<div class="grand"><span>Grand total</span><span>₹'+d.total+'</span></div>';
  }catch(e){ document.getElementById('bd').innerHTML='Could not load charges'; }
}
async function placeOrder(){
  var msg=document.getElementById('msg'); msg.style.display='none';
  var body={paymentMethod:payMethod};
  if(payMethod==='ONLINE'){
    var upi=document.getElementById('upiId').value.trim();
    var pin=document.getElementById('upiPin').value;
    if(!upi||upi.indexOf('@')<0){ show('err','Valid UPI ID required'); return; }
    if(!pin||pin.length<4){ show('err','PIN min 4 digits'); return; }
    body.upiId=upi;
  }
  try{
    const r=await fetch('api/orders',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    const j=await r.json();
    if(j.success){
      show('ok', j.data.message);
      renderBill(j.data);
      document.getElementById('placeBtn').disabled=true;
      setTimeout(function(){ location='orders.jsp'; }, 6000);
    } else show('err', j.error?j.error.message:'Failed');
  }catch(e){ show('err','Network error'); }
}
function renderBill(d){
  var bill=document.getElementById('bill'); bill.style.display='block';
  var rows='';
  if(d.items) d.items.forEach(function(it){
    rows+='<tr><td>'+it.product+'</td><td>'+it.qty+'</td><td>₹'+it.unitPrice+'</td><td>₹'+it.lineTotal+'</td></tr>';
  });
  bill.innerHTML='<h3 style="color:#2dd4bf">Payment Bill</h3>'+
    '<p><b>Order #</b>'+d.orderId+' · <b>Payment</b> '+d.paymentMethod+(d.upiId?' ('+d.upiId+')':'')+'</p>'+
    '<p><b>Buyer:</b> '+(d.buyerName||'')+' · '+(d.buyerEmail||'')+'</p>'+
    '<table><tr><th>Item</th><th>Qty</th><th>Price</th><th>Amount</th></tr>'+rows+
    '<tr><td colspan="3">Subtotal</td><td>₹'+d.subtotal+'</td></tr>'+
    '<tr><td colspan="3">Service charge</td><td>₹'+d.serviceCharge+'</td></tr>'+
    '<tr><td colspan="3">Delivery</td><td>₹'+d.deliveryCharge+'</td></tr>'+
    '<tr><td colspan="3" style="color:#2dd4bf;font-weight:700">Grand Total</td><td style="color:#2dd4bf;font-weight:700">₹'+d.total+'</td></tr></table>';
}
function show(cls,text){ var m=document.getElementById('msg'); m.className='msg '+cls; m.innerText=text; m.style.display='block'; }
loadQuote();
</script></body></html>
