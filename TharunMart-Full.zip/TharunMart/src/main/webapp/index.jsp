<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Tharun Mart</title>
<style>
:root{
  --bg:#050814;--bg2:#0a1228;--card:rgba(10,30,60,.55);--line:rgba(0,200,255,.18);
  --cyan:#2dd4bf;--blue:#10b981;--violet:#7c3aed;--text:#e8f4ff;--muted:#8ba3c7;--pink:#f472b6;
}
*{box-sizing:border-box;margin:0;padding:0;font-family:'Segoe UI',system-ui,sans-serif}
body{min-height:100vh;background:radial-gradient(ellipse at 20% 0%,#0d1b3d 0%,#050814 45%,#02040a 100%);color:var(--text)}
body::before{content:'';position:fixed;inset:0;background-image:linear-gradient(rgba(0,229,255,.03) 1px,transparent 1px),linear-gradient(90deg,rgba(0,229,255,.03) 1px,transparent 1px);background-size:48px 48px;pointer-events:none;z-index:0}
.nav,.hero,.toolbar,.grid,.chat-box,.chat-btn{position:relative;z-index:1}
.nav{display:flex;align-items:center;justify-content:space-between;padding:12px 24px;background:rgba(5,12,28,.92);backdrop-filter:blur(16px);border-bottom:1px solid var(--line);position:sticky;top:0;z-index:50;flex-wrap:wrap;gap:8px}
.brand{display:flex;align-items:center;gap:10px;text-decoration:none;color:var(--text)}
.brand svg{filter:drop-shadow(0 0 8px rgba(0,229,255,.45))}
.brand span{font-size:1.25rem;font-weight:700;letter-spacing:.5px;background:linear-gradient(90deg,#2dd4bf,#10b981);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.nav-links{display:flex;gap:4px;align-items:center;flex-wrap:wrap}
.nav-links a,.nav-links button{color:var(--muted);text-decoration:none;padding:8px 12px;border-radius:8px;font-size:.88rem;background:transparent;border:1px solid transparent;cursor:pointer}
.nav-links a:hover,.nav-links button:hover{color:var(--cyan);border-color:var(--line);background:rgba(0,229,255,.06)}
.user-pill{background:rgba(0,229,255,.12);color:var(--cyan);padding:6px 12px;border-radius:20px;font-size:.8rem;border:1px solid var(--line)}
.hero{text-align:center;padding:40px 20px 16px}
.hero h1{font-size:1.85rem;margin-bottom:8px;text-shadow:0 0 24px rgba(0,229,255,.25)}
.hero p{color:var(--muted)}
.toolbar{max-width:1100px;margin:0 auto 20px;padding:0 20px;display:flex;gap:10px;flex-wrap:wrap}
.toolbar input,.toolbar select{flex:1;min-width:130px;padding:11px 14px;border-radius:10px;border:1px solid var(--line);background:#0a1628;color:var(--text)}
.toolbar select option{background:#0a1628;color:#fff}
.toolbar button{padding:11px 20px;border:none;border-radius:10px;background:linear-gradient(135deg,#14b8a6,#10b981);color:#fff;font-weight:600;cursor:pointer;box-shadow:0 0 16px rgba(0,180,216,.25)}
.grid{max-width:1100px;margin:0 auto;padding:0 20px 110px;display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:18px}
.card{background:var(--card);border:1px solid var(--line);border-radius:20px;overflow:hidden;transition:.2s;backdrop-filter:blur(8px)}
.card:hover{transform:translateY(-4px);border-color:rgba(0,229,255,.4);box-shadow:0 0 24px rgba(0,180,216,.15)}
.card img{width:100%;height:175px;object-fit:cover;background:#0a1628}
.card-body{padding:14px}
.card h3{font-size:.98rem;margin-bottom:4px}
.meta{color:var(--muted);font-size:.78rem;margin-bottom:8px}
.price{color:var(--cyan);font-weight:700;font-size:1.15rem;text-shadow:0 0 12px rgba(0,229,255,.3)}
.actions{display:flex;gap:8px;margin-top:12px}
.btn{flex:1;padding:9px;border:none;border-radius:9px;cursor:pointer;font-weight:600;font-size:.85rem;text-align:center;text-decoration:none;line-height:2}
.btn-primary{background:linear-gradient(135deg,#14b8a6,#2563eb);color:#fff}
.btn-ghost{background:rgba(0,229,255,.08);color:var(--text);border:1px solid var(--line)}
.empty{text-align:center;padding:60px;color:var(--muted)}
.chat-btn{position:fixed;bottom:24px;right:24px;width:58px;height:58px;border-radius:50%;border:1px solid var(--line);background:linear-gradient(135deg,#0ea5e9,#10b981);color:#fff;font-size:1.2rem;cursor:pointer;box-shadow:0 0 24px rgba(14,165,233,.4);z-index:100}
.chat-box{display:none;position:fixed;bottom:92px;right:24px;width:350px;max-height:450px;background:#071020;border:1px solid var(--line);border-radius:20px;flex-direction:column;z-index:100;overflow:hidden;box-shadow:0 0 40px rgba(0,180,216,.2)}
.chat-box.open{display:flex}
.chat-head{padding:12px 16px;background:linear-gradient(90deg,rgba(14,165,233,.25),rgba(59,130,246,.15));font-weight:600;border-bottom:1px solid var(--line);display:flex;align-items:center;gap:8px}
.chat-msgs{flex:1;overflow-y:auto;padding:12px;display:flex;flex-direction:column;gap:8px;min-height:250px;max-height:290px}
.msg{padding:10px 12px;border-radius:12px;font-size:.86rem;max-width:92%;line-height:1.4}
.msg.bot{background:rgba(0,229,255,.08);border:1px solid var(--line);align-self:flex-start}
.msg.user{background:rgba(59,130,246,.25);align-self:flex-end}
.chat-input{display:flex;border-top:1px solid var(--line)}
.chat-input input{flex:1;padding:12px;border:none;background:transparent;color:#fff;outline:none}
.chat-input button{padding:12px 16px;border:none;background:var(--blue);color:#fff;cursor:pointer}
</style>
</head>
<body>
<nav class="nav">
  <a class="brand" href="index.jsp">
    <svg width="36" height="36" viewBox="0 0 64 64" fill="none">
      <rect x="4" y="4" width="56" height="56" rx="14" stroke="#2dd4bf" stroke-width="2.5" fill="rgba(0,229,255,.08)"/>
      <path d="M18 40V24h8c5 0 8 2.5 8 7s-3 9-8 9h-8zm8-5c2.2 0 3.5-1.2 3.5-3.5S28.2 28 26 28h-3v7h3z" fill="#2dd4bf"/>
      <path d="M38 40V24h12v5h-7v2h6v4h-6v5H38z" fill="#10b981"/>
      <circle cx="50" cy="14" r="3" fill="#2dd4bf"/>
    </svg>
    <span>Tharun Mart</span>
  </a>
  <div class="nav-links" id="navLinks"></div>
</nav>
<div class="hero">
  <h1>Discover deals from local sellers</h1>
  <p>Browse · cart · COD or UPI · track your orders</p>
</div>
<div class="toolbar">
  <input id="q" placeholder="Search products..." onkeydown="if(event.key==='Enter')load()">
  <select id="cat">
    <option value="">All categories</option>
    <option value="Electronics">Electronics</option>
    <option value="Fashion">Fashion</option>
    <option value="Other">Other</option>
  </select>
  <select id="sort">
    <option value="">Default</option>
    <option value="price_asc">Price: Low to High</option>
    <option value="price_desc">Price: High to Low</option>
    <option value="name">Name A-Z</option>
  </select>
  <button onclick="load()">Search</button>
</div>
<div class="grid" id="grid"><div class="empty">Loading products...</div></div>
<button class="chat-btn" onclick="toggleChat()" title="TM Assistant">CM</button>
<div class="chat-box" id="chatBox">
  <div class="chat-head">
    <svg width="22" height="22" viewBox="0 0 64 64"><rect x="6" y="6" width="52" height="52" rx="12" stroke="#2dd4bf" stroke-width="3" fill="rgba(0,229,255,.1)"/><text x="32" y="40" text-anchor="middle" fill="#2dd4bf" font-size="22" font-weight="700" font-family="Segoe UI">CM</text></svg>
    TM Assistant
  </div>
  <div class="chat-msgs" id="chatMsgs"><div class="msg bot">Hi! I'm <b>TM Assistant</b> for Tharun Mart. Ask about products, delivery charges, COD/UPI, cart...</div></div>
  <div class="chat-input">
    <input id="chatIn" placeholder="Message TM Assistant..." onkeydown="if(event.key==='Enter')sendChat()">
    <button onclick="sendChat()">Send</button>
  </div>
</div>
<script>
var currentUser=null;
async function initNav(){
  try{ const r=await fetch('api/auth/me'); const j=await r.json(); if(j.success) currentUser=j.data; }catch(e){}
  var html='';
  if(currentUser){
    html+='<span class="user-pill">'+currentUser.name+' · '+currentUser.role+'</span>';
    if(currentUser.role==='BUYER') html+='<a href="index.jsp">Shop</a><a href="cart.jsp">Cart</a><a href="orders.jsp">My Orders</a>';
    else if(currentUser.role==='SELLER') html+='<a href="seller.jsp">Seller Dashboard</a><a href="index.jsp">Store</a>';
    else if(currentUser.role==='ADMIN') html+='<a href="admin.jsp">Admin Panel</a><a href="index.jsp">Store</a>';
    html+='<button onclick="logout()">Logout</button>';
  } else html+='<a href="index.jsp">Shop</a><a href="login.jsp">Login</a><a href="register.jsp">Register</a>';
  document.getElementById('navLinks').innerHTML=html;
}
async function logout(){ await fetch('api/auth/logout'); location='index.jsp'; }
async function load(){
  var url='api/products?', q=document.getElementById('q').value, c=document.getElementById('cat').value;
  if(q) url+='q='+encodeURIComponent(q)+'&';
  if(c) url+='category='+encodeURIComponent(c)+'&';
  try{
    const r=await fetch(url); const j=await r.json();
    var el=document.getElementById('grid');
    if(!j.success||!j.data||!j.data.length){ el.innerHTML='<div class="empty">No products found.</div>'; return; }
    var list=j.data.slice(), sort=document.getElementById('sort').value;
    if(sort==='price_asc') list.sort(function(a,b){return Number(a.price)-Number(b.price);});
    if(sort==='price_desc') list.sort(function(a,b){return Number(b.price)-Number(a.price);});
    if(sort==='name') list.sort(function(a,b){return (a.name||'').localeCompare(b.name||'');});
    var isBuyer = currentUser && currentUser.role==='BUYER';
    el.innerHTML=list.map(function(p){
      var actions = isBuyer
        ? '<button class="btn btn-primary" onclick="addCart('+p.id+')">Add to Cart</button><a class="btn btn-ghost" href="product.jsp?id='+p.id+'">View</a>'
        : '<a class="btn btn-ghost" href="product.jsp?id='+p.id+'" style="flex:1">View details</a>';
      return '<div class="card"><a href="product.jsp?id='+p.id+'"><img src="'+(p.imageUrl||'https://via.placeholder.com/400x300?text=Product')+'" alt=""></a>'+
        '<div class="card-body"><h3>'+p.name+'</h3><div class="meta">'+(p.category||'General')+' · '+(p.sellerName||'Seller')+'</div>'+
        '<div class="price">₹'+p.price+'</div><div class="actions">'+actions+'</div></div></div>';
    }).join('');
  }catch(e){ document.getElementById('grid').innerHTML='<div class="empty">Could not load products.</div>'; }
}
async function addCart(id){
  if(!currentUser||currentUser.role!=='BUYER'){ alert('Login as Buyer'); location='login.jsp'; return; }
  const r=await fetch('api/cart',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({productId:id,quantity:1})});
  const j=await r.json();
  if(j.success) alert('Added to cart!'); else alert(j.error?j.error.message:'Failed');
}
function toggleChat(){ document.getElementById('chatBox').classList.toggle('open'); }
async function sendChat(){
  var input=document.getElementById('chatIn'); var msg=input.value.trim(); if(!msg) return;
  var box=document.getElementById('chatMsgs');
  box.innerHTML+='<div class="msg user">'+msg+'</div>'; input.value='';
  try{
    const r=await fetch('api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:msg})});
    const j=await r.json();
    box.innerHTML+='<div class="msg bot">'+(j.data&&j.data.reply?j.data.reply:'No reply')+'</div>';
  }catch(e){ box.innerHTML+='<div class="msg bot">TM Assistant offline.</div>'; }
  box.scrollTop=box.scrollHeight;
}
initNav().then(load);
</script>
</body>
</html>
