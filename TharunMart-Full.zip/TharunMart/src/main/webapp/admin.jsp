<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Admin - Tharun Mart</title>
<style>
:root{--line:rgba(0,200,255,.18);--cyan:#2dd4bf;--text:#e8f4ff;--muted:#8ba3c7}
*{box-sizing:border-box;margin:0;padding:0;font-family:Segoe UI,sans-serif}
body{min-height:100vh;background:radial-gradient(ellipse at 20% 0%,#0d1b3d,#050814);color:var(--text)}
.nav{display:flex;justify-content:space-between;padding:12px 24px;background:rgba(5,12,28,.92);border-bottom:1px solid var(--line);align-items:center}
.nav a,.nav button{color:var(--muted);text-decoration:none;margin-left:12px;background:none;border:none;cursor:pointer}
.brand{color:var(--cyan);font-weight:700;display:flex;align-items:center;gap:8px}
.wrap{max-width:1100px;margin:24px auto;padding:0 20px}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin-bottom:20px}
.stat{background:rgba(10,30,60,.55);border:1px solid var(--line);border-radius:14px;padding:16px;text-align:center}
.stat b{display:block;font-size:1.5rem;color:var(--cyan)}
.tabs{display:flex;gap:8px;margin-bottom:14px;flex-wrap:wrap}
.tabs button{padding:10px 16px;border-radius:10px;border:1px solid var(--line);background:rgba(0,0,0,.25);color:var(--muted);cursor:pointer}
.tabs button.on{background:rgba(0,229,255,.15);color:var(--cyan);border-color:var(--cyan)}
.card{background:rgba(10,30,60,.55);border:1px solid var(--line);border-radius:16px;padding:18px;overflow-x:auto}
table{width:100%;border-collapse:collapse;font-size:.88rem}
th,td{padding:10px 8px;border-bottom:1px solid rgba(255,255,255,.08);text-align:left}
th{color:var(--cyan);font-weight:600}
.badge{display:inline-block;padding:3px 8px;border-radius:12px;font-size:.75rem}
.BUYER{background:rgba(59,130,246,.2);color:#93c5fd}
.SELLER{background:rgba(52,211,153,.15);color:#6ee7b7}
.ADMIN{background:rgba(244,114,182,.15);color:#f9a8d4}
.COD{background:rgba(251,191,36,.15);color:#fbbf24}
.UPI{background:rgba(0,229,255,.15);color:var(--cyan)}
.del{background:#ef4444;color:#fff;border:none;padding:5px 10px;border-radius:6px;cursor:pointer;font-size:.8rem}
</style></head><body>
<nav class="nav">
  <div class="brand">
    <svg width="28" height="28" viewBox="0 0 64 64"><rect x="4" y="4" width="56" height="56" rx="12" stroke="#2dd4bf" stroke-width="2.5" fill="rgba(0,229,255,.08)"/><text x="32" y="40" text-anchor="middle" fill="#2dd4bf" font-size="18" font-weight="700">CM</text></svg>
    Admin Panel
  </div>
  <div><a href="index.jsp">Store</a><button onclick="logout()">Logout</button></div>
</nav>
<div class="wrap">
  <div class="stats" id="stats"></div>
  <div class="tabs">
    <button class="on" id="tUsers" onclick="showTab('users')">Users</button>
    <button id="tOrders" onclick="showTab('orders')">Orders & Payments</button>
    <button id="tProducts" onclick="showTab('products')">Products</button>
  </div>
  <div class="card"><div id="panel">Loading...</div></div>
</div>
<script>
async function init(){
  const r=await fetch('api/auth/me'); const j=await r.json();
  if(!j.success||j.data.role!=='ADMIN'){ alert('Admin only'); location='login.jsp'; return; }
  loadStats(); showTab('users');
}
async function logout(){ await fetch('api/auth/logout'); location='index.jsp'; }
async function loadStats(){
  const r=await fetch('api/admin/stats'); const j=await r.json();
  if(!j.success) return;
  var s=j.data;
  document.getElementById('stats').innerHTML=
    '<div class="stat"><b>'+s.totalUsers+'</b>Users</div>'+
    '<div class="stat"><b>'+s.buyers+'</b>Buyers</div>'+
    '<div class="stat"><b>'+s.sellers+'</b>Sellers</div>'+
    '<div class="stat"><b>'+s.totalOrders+'</b>Orders</div>'+
    '<div class="stat"><b>'+s.totalProducts+'</b>Products</div>';
}
function showTab(tab){
  document.getElementById('tUsers').className = tab==='users'?'on':'';
  document.getElementById('tOrders').className = tab==='orders'?'on':'';
  document.getElementById('tProducts').className = tab==='products'?'on':'';
  if(tab==='users') loadUsers();
  else if(tab==='orders') loadOrders();
  else loadProducts();
}
async function loadUsers(){
  const r=await fetch('api/admin/users'); const j=await r.json();
  if(!j.success){ document.getElementById('panel').innerHTML='Error'; return; }
  var h='<table><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Joined</th></tr>';
  j.data.forEach(function(u){
    var d=u.createdAt?String(u.createdAt).substring(0,10):'';
    h+='<tr><td>'+u.id+'</td><td>'+u.name+'</td><td>'+u.email+'</td><td><span class="badge '+u.role+'">'+u.role+'</span></td><td>'+d+'</td></tr>';
  });
  document.getElementById('panel').innerHTML=h+'</table>';
}
async function loadOrders(){
  const r=await fetch('api/admin/orders'); const j=await r.json();
  if(!j.success){ document.getElementById('panel').innerHTML='Error'; return; }
  if(!j.data.length){ document.getElementById('panel').innerHTML='No orders yet'; return; }
  var h='<table><tr><th>Order</th><th>Buyer</th><th>Email</th><th>Pay</th><th>Subtotal</th><th>Service</th><th>Delivery</th><th>Total</th><th>Status</th><th>Date</th></tr>';
  j.data.forEach(function(o){
    var d=o.createdAt?String(o.createdAt).substring(0,10):'';
    h+='<tr><td>#'+o.id+'</td><td>'+o.buyerName+'</td><td>'+o.buyerEmail+'</td>'+
      '<td><span class="badge '+(o.paymentMethod||'')+'">'+(o.paymentMethod||'')+'</span></td>'+
      '<td>₹'+o.subtotal+'</td><td>₹'+o.serviceCharge+'</td><td>₹'+o.deliveryCharge+'</td>'+
      '<td style="color:#2dd4bf;font-weight:600">₹'+o.totalAmount+'</td><td>'+o.status+'</td><td>'+d+'</td></tr>';
  });
  document.getElementById('panel').innerHTML=h+'</table>';
}
async function loadProducts(){
  const r=await fetch('api/admin/products'); const j=await r.json();
  if(!j.success){ document.getElementById('panel').innerHTML='Error'; return; }
  var h='<table><tr><th>ID</th><th>Name</th><th>Price</th><th>Seller</th><th>Stock</th><th>Category</th><th></th></tr>';
  j.data.forEach(function(p){
    h+='<tr><td>'+p.id+'</td><td>'+p.name+'</td><td>₹'+p.price+'</td><td>'+(p.sellerName||'')+'</td><td>'+p.stockQty+
      '</td><td>'+(p.category||'')+'</td><td><button class="del" onclick="del('+p.id+')">Remove</button></td></tr>';
  });
  document.getElementById('panel').innerHTML=h+'</table>';
}
async function del(id){
  if(!confirm('Remove product?')) return;
  const r=await fetch('api/products/'+id,{method:'DELETE'}); const j=await r.json();
  if(j.success){ loadProducts(); loadStats(); } else alert(j.error?j.error.message:'Failed');
}
init();
</script></body></html>
