package com.onlinmart.onlinmart.listener;

import com.onlinmart.onlinmart.util.PasswordUtil;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

@WebListener
public class DataSourceListener implements ServletContextListener {
    private HikariDataSource dataSource;

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        System.out.println(">>> Tharun Mart DataSource starting (FILE mode - data persists)...");
        try {
            HikariConfig config = new HikariConfig();
            // FILE mode: data saved on disk, survives Tomcat restart
            // File created as: <tomcat-folder>/tharunmart-data.mv.db
            config.setJdbcUrl("jdbc:h2:file:./tharunmart-data;AUTO_SERVER=TRUE;MODE=MySQL;DB_CLOSE_DELAY=-1");
            config.setUsername("sa");
            config.setPassword("");
            config.setDriverClassName("org.h2.Driver");
            config.setMaximumPoolSize(10);
            dataSource = new HikariDataSource(config);
            sce.getServletContext().setAttribute("dataSource", dataSource);

            try (Connection conn = dataSource.getConnection(); Statement stmt = conn.createStatement()) {
                // Create tables only if missing
                stmt.execute("CREATE TABLE IF NOT EXISTS users (" +
                        "id BIGINT AUTO_INCREMENT PRIMARY KEY, " +
                        "name VARCHAR(100) NOT NULL, " +
                        "email VARCHAR(150) NOT NULL UNIQUE, " +
                        "password_hash VARCHAR(255) NOT NULL, " +
                        "role VARCHAR(20) NOT NULL, " +
                        "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");

                stmt.execute("CREATE TABLE IF NOT EXISTS products (" +
                        "id BIGINT AUTO_INCREMENT PRIMARY KEY, " +
                        "seller_id BIGINT NOT NULL, " +
                        "name VARCHAR(200) NOT NULL, " +
                        "description CLOB, " +
                        "price DECIMAL(10,2) NOT NULL, " +
                        "stock_qty INT DEFAULT 0, " +
                        "category VARCHAR(100), " +
                        "image_url VARCHAR(500), " +
                        "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");

                stmt.execute("CREATE TABLE IF NOT EXISTS orders (" +
                        "id BIGINT AUTO_INCREMENT PRIMARY KEY, " +
                        "buyer_id BIGINT NOT NULL, " +
                        "status VARCHAR(20) DEFAULT 'PENDING', " +
                        "subtotal DECIMAL(10,2) DEFAULT 0, " +
                        "service_charge DECIMAL(10,2) DEFAULT 0, " +
                        "delivery_charge DECIMAL(10,2) DEFAULT 0, " +
                        "total_amount DECIMAL(10,2) NOT NULL, " +
                        "payment_method VARCHAR(20) DEFAULT 'COD', " +
                        "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");

                stmt.execute("CREATE TABLE IF NOT EXISTS order_items (" +
                        "id BIGINT AUTO_INCREMENT PRIMARY KEY, " +
                        "order_id BIGINT NOT NULL, " +
                        "product_id BIGINT NOT NULL, " +
                        "quantity INT NOT NULL, " +
                        "unit_price DECIMAL(10,2) NOT NULL)");

                stmt.execute("CREATE TABLE IF NOT EXISTS cart_items (" +
                        "id BIGINT AUTO_INCREMENT PRIMARY KEY, " +
                        "user_id BIGINT NOT NULL, " +
                        "product_id BIGINT NOT NULL, " +
                        "quantity INT DEFAULT 1)");

                stmt.execute("CREATE TABLE IF NOT EXISTS reviews (" +
                        "id BIGINT AUTO_INCREMENT PRIMARY KEY, " +
                        "product_id BIGINT NOT NULL, " +
                        "user_id BIGINT NOT NULL, " +
                        "rating INT NOT NULL, " +
                        "comment CLOB, " +
                        "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");

                // Seed ONLY when users table is empty (first run)
                ResultSet rs = stmt.executeQuery("SELECT COUNT(*) AS cnt FROM users");
                rs.next();
                int count = rs.getInt("cnt");

                if (count == 0) {
                    System.out.println(">>> First run: seeding demo users and products...");
                    String hash = PasswordUtil.hash("password123");
                    stmt.execute("INSERT INTO users (name, email, password_hash, role) VALUES " +
                            "('Admin', 'admin@tharunmart.com', '" + hash + "', 'ADMIN')," +
                            "('Ravi Seller', 'ravi@tharunmart.com', '" + hash + "', 'SELLER')," +
                            "('Amit Buyer', 'amit@tharunmart.com', '" + hash + "', 'BUYER')");
                    stmt.execute("INSERT INTO products (seller_id, name, description, price, stock_qty, category, image_url) VALUES " +
                            "(2, 'Wireless Headphones', 'Noise cancelling headphones with deep bass', 2499.00, 50, 'Electronics', 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400')," +
                            "(2, 'Smart Watch', 'Fitness tracking smartwatch with heart rate', 3999.00, 30, 'Electronics', 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400')," +
                            "(2, 'Running Shoes', 'Lightweight breathable running shoes', 2199.00, 40, 'Fashion', 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400')," +
                            "(2, 'Cotton T-Shirt', 'Premium soft cotton t-shirt', 599.00, 100, 'Fashion', 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400')");
                    System.out.println(">>> Seed complete.");
                } else {
                    System.out.println(">>> Existing data found (" + count + " users). Skipping seed.");
                }
            }
            System.out.println(">>> Tharun Mart DataSource OK (persistent file: ./tharunmart-data)");
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        if (dataSource != null && !dataSource.isClosed()) dataSource.close();
    }
}
