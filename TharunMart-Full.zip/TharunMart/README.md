# TharunMart

Online multi-seller shopping website where buyers can browse, order and pay, sellers can manage products, and admin can monitor users and orders.

## Demo login (password: password123)

- Admin: admin@tharunmart.com
- Seller: ravi@tharunmart.com
- Buyer: amit@tharunmart.com

## Run

```bash
mvn clean package
```

Deploy the WAR `target/TharunMart.war` to Apache Tomcat 9, then open:

http://localhost:8080/TharunMart/
